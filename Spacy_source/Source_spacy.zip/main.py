# -*- coding: utf-8 -*-

from pln import PLN

# Input
descricao = input("Informe a descrição: ")

# PLN
pln = PLN()

pln.analisar(descricao)
